/*
QSS Core JavaScript
By: Light Media <Aakash Bhatia>
http://lightmedia.com.au/
*/

/* Controls for the Map details on the home page Start */
